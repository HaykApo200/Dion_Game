const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

const record = document.getElementById("record");
const record_now = document.getElementById("now_record")
let record_num = 0;
let num = 1;

setInterval(function(){
    record_now.innerHTML = record_num;
    record_num += num;
    if((dino.x >= (cactus.x - 5)) && (dino.x <= (cactus.x + 5)) && (dino.y == (cactus.y - 15))){
        if(record.innerHTML < record_now.innerHTML){
            record.innerHTML = record_now.innerHTML;
            num = 0;
        }else{
            num = 0;
        }
    }
},100);

function Dino(x,y,width,height){
    const dinoImage = document.createElement("img");
    dinoImage.src = "image/dino.webp";

    let yDelta = 0;
    const yConst = y;
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;

    this.update = () => {
        ctx.drawImage(dinoImage,this.x,this.y,this.width,this.height);
    }

    this.jump = () => {
        if(this.y < (yConst - yDelta)){
            this.y = yConst - yDelta
        }
        yDelta = -90;
        this.y += yDelta;
        
    }

    this.down = () => {
        yDelta = 0;
        this.y = yConst;
    }

}

function Cactus(x,y,width,height){
    const cactusImage = document.createElement("img");
    cactusImage.src = "image/cac.png";

    const xDeltaConst = 5;
    let xDelta = xDeltaConst;
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;  

    this.update = () => {
        ctx.drawImage(cactusImage,this.x,this.y,this.width,this.height);
        this.x -= xDelta;
    }

    this.move = () => {
        this.x -= xDelta;
    }

    this.restart = () => {
        if(((this.x <= 600) && (this.x >= 0)) == false){
            this.x = 600;
        }
    }

    this.new = () => {
        xDelta = xDeltaConst;
        this.x = 550;
        this.y = 155;
    }

    this.stop = () => {
        xDelta = 0;
    }
}

let dino = new Dino(70,140,60,60);
let cactus = new Cactus(550,155,40,40);

function gameOver(){
    if((dino.x >= (cactus.x - 5)) && (dino.x <= (cactus.x + 5)) && (dino.y == (cactus.y - 15)) ){
        cactus.stop()
    }
}

function line(){
    ctx.beginPath();
    ctx.moveTo(0, 195);
    ctx.lineTo(600, 195);
    ctx.stroke();
}

function update(){

    ctx.clearRect(0,0,canvas.width,canvas.height);
    line();
    cactus.update();
    dino.update();
    cactus.restart();
}

function loop(){
    requestAnimationFrame(loop);
    update();
    gameOver();
}

loop();

document.addEventListener("keydown", (evt) => {
    if(evt.code === "ArrowUp"){
        dino.jump();
    }
})

document.addEventListener("keyup",() => {
    dino.down();
})

document.addEventListener("keydown",(evt) => {
    if(evt.code === "Space"){
        cactus.new();
        num = 1;
        record_num = 0
    }
})
